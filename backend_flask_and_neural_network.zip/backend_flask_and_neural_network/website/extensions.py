#!/usr/bin/env python
# coding=utf-8

from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()

__all__ = ['db']
