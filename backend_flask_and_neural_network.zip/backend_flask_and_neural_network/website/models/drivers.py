#!/usr/bin/env python
# coding=utf-8
import datetime
from website.extensions import db

#驾驶行为
class Drivers_act(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    start_time = db.Column(db.DateTime,default=datetime.datetime.now(),doc='开始时间')
    end_time = db.Column(db.DateTime,default=datetime.datetime.now(),doc='结束时间')
    desc = db.Column(db.String(400),doc='行为评价') #c1,c2
    place = db.Column(db.String(300),doc='地点')
    act_id = db.Column(db.Integer,doc='行为id')
    pic = db.Column(db.String(30),doc='行为对应的图片名字')

    user_drive_record = db.Column(db.Integer,default=0,doc='属于用户的第几次驾驶')
    is_start = db.Column(db.Boolean,default=False,doc="是否开始")
    is_finish = db.Column(db.Boolean,default=False,doc="是否结束")

    userId = db.Column(db.Integer,db.ForeignKey('user.id'))


    def __init__(self,desc,record,start,end):
        self.desc = desc
        self.user_drive_record = record
        self.start_time = start
        self.end_time = end


    def __repr__(self):
        return '<act %s %s>' % (self.end_time,self.desc)

    def save(self):
        db.session.add(self)
        db.session.commit()
    def update(self):
        db.session.commit()