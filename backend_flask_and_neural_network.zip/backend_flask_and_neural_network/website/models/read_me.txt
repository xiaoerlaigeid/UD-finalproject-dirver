在此件夹放置数据库模型文件
关于 Flask-SQLAlchemy
快速入门 http://www.pythondoc.com/flask-sqlalchemy/quickstart.html#
官方Tutorial http://docs.sqlalchemy.org/en/rel_1_1/orm/tutorial.html
注意 Flask-SQLAlchemy 是 SQLAlchemy 为Flask写的一个拓展，Flask-SQLAlchemy 与 SQLAlchemy 语法稍有不同

