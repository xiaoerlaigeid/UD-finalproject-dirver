#!/usr/bin/env python
# coding=utf-8
import datetime
from website.extensions import db

def caculate_age(born):
    today = datetime.date.today()
    try:
        birthday = born.replace(year=today.year)
    except ValueError:
        birthday = born.replace(year = today.year ,day=born.day - 1)
    if birthday > today:
        return today.year - born.year - 1
    else:
        return today.year - born.year


class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(80),doc='司机姓名')
    birth = db.Column(db.Date,default=datetime.date.today(),doc='出生日期')
    work_start_time = db.Column(db.Date,default=datetime.date.today(),doc='进入公司时间')
    account = db.Column(db.String(12),unique=True,index=True,doc='用户工号')
    # identity = db.Column(db.Integer,default=0)
    password = db.Column(db.String(12)) #密码

    bad_record = db.Column(db.Integer,default=0,doc='历史不良驾驶记录数')
    drive_record = db.Column(db.Integer,default=0,doc='驾驶次数')
    safe_drive_record = db.Column(db.Integer,default=0,doc='安全驾驶次数')

    car_id = db.Column(db.String(11),doc='车牌号')

    is_admin = db.Column(db.Boolean,default=False) #是否是管理员
    drivers_act = db.relationship('Drivers_act',backref = 'user',lazy = 'dynamic')

    def __init__(self,acc,pawd):
        self.account = acc
        self.password = pawd

    def is_authenticated(self):
        return True

    def is_active(self):
        return True

    def is_anonymous(self):
        return False

    def get_id(self):
        # try:
        #     return unicode(self.id)  # python 2
        # except NameError:
        return str(self.id)  # python 3

    def save(self):
        db.session.add(self)
        db.session.commit()

    def get_age(self):
        return caculate_age(self.birth)
    def get_work_day(self):
        return caculate_age(self.work_start_time)
    def __repr__(self):
           return '<User %r>' % (self.name)



