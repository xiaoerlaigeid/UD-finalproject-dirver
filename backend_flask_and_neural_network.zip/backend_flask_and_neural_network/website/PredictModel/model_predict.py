from keras.applications.vgg16 import VGG16
from keras.preprocessing import image
from keras.applications.vgg16 import preprocess_input, decode_predictions
import numpy as np
from keras.models import Sequential   #导入Sequential模型  
from keras.layers.core import Flatten, Dense, Dropout  
from keras.layers.convolutional import Convolution2D, MaxPooling2D, ZeroPadding2D  
from keras.optimizers import SGD  
from keras.layers import Input
from keras.applications.vgg16 import VGG16
from keras.preprocessing import image
from keras.applications.vgg16 import preprocess_input
from keras.models import Model
from keras.layers import  GlobalAveragePooling2D

def resultconert(s):
    data = {
        "safe driving":"c0",
        "texting - right":"c1",
        "talking on the phone - right":"c2",
        "texting - left":"c3",
        "talking on the phone - left":"c4",
        "operating the radio":"c5",
        "drinking":"c6",
        "reaching behind":"c7",
        "hair and makeup":"c8",
        "talking to passenger":"c9"
    }
    return data.get(s,"None")

def create_model():
    y = Input((128, 128, 3))
    x = Conv2D(32, (5, 5), padding = "same", activation = 'relu', name = "layer1_con1")(y)
    x = MaxPooling2D(pool_size = (2, 2), strides = (2, 2), padding = 'same', name = "layer1_pool")(x)
    x = Conv2D(64, (5, 5), padding = "same", activation = 'relu', name = "layer2_con1")(x)
    x = Conv2D(64, (5, 5), padding = "same", activation = 'relu', name = "layer2_con2")(x)
    x = MaxPooling2D(pool_size = (2, 2), strides = (2, 2), padding = 'same', name = "layer2_pool")(x)
    x = Conv2D(128, (5, 5), padding = "same", activation = 'relu', name = "layer3_con1")(x)
    x = Conv2D(128, (5, 5), padding = "same", activation = 'relu', name = "layer3_con2")(x)
    x = MaxPooling2D(pool_size = (2, 2), strides = (2, 2), padding = 'same', name = "layer3_pool")(x)
    x = Conv2D(192, (5, 5), padding = "same", activation = 'relu', name = "layer4_con1")(x)
    x = Conv2D(192, (5, 5), padding = "same", activation = 'relu', name = "layer4_con2")(x)
    x = Conv2D(192, (5, 5), padding = "same", activation = 'relu', name = "layer4_con3")(x)
    x = MaxPooling2D(pool_size = (2, 2), strides = (2, 2), padding = 'same', name = "layer4_pool")(x)
    x = Flatten()(x)
    x = Dense(100,activation='relu')(x)#yzk add
    x = Dropout(0.5)(x)
    out = Dense(10, activation = 'softmax')(x)
    model = Model(inputs = y, outputs = out)
    model.load_weights('district_driver.h5',by_name=True)
    return model
    


def predict(img_path):
	
    img = image.load_img(img_path, target_size=(128, 128))
    x = image.img_to_array(img)
    x = np.expand_dims(x, axis=0)
    x = preprocess_input(x)
    model=create_model()
    preds = model.predict(x)
    # decode the results into a list of tuples (class, description, probability)
    # (one such list for each sample in the batch)
    # print('Predicted:', decode_predictions(preds, top=3)[0])
    res = decode_predictions(preds, top=3)
    return res[0][0][1] if res else ""


# if  '__name__' == '__main__':
#     import tensorflow as tf
#
#     a = tf.random_normal((100, 100))
#     b = tf.random_normal((100, 500))
#     c = tf.matmul(a, b)
#     sess = tf.InteractiveSession()
#     sess.run(c)
    # print(predict('E:\\javascript\\Pictures\\aa3-281x300.jpg'))
