# coding=utf-8
from datetime import date, datetime
from flask import Blueprint,session,request
from website.models import User,Drivers_act
from website.helpers.tools import succeed, error
from flask_login import login_required,current_user
from website.helpers.decorators import admin_required
from website.models.drivers import Drivers_act
from sqlalchemy import func
import redis

adminapi = Blueprint('admin_api', __name__)
r = redis.Redis(host='localhost', port=6379, decode_responses=True)


@adminapi.route('/get_workers_list',methods = ['post'])
@admin_required
@login_required
def getworkers():
    num = int(request.get_json(force=True).get('num',0))
    order = request.get_json(force=True).get('order',True) #True 为正序 ， False 为倒序
    if order:
        users = User.query.filter_by(is_admin = False).order_by(User.bad_record).limit(num+10)
    else:
        users = User.query.filter_by(is_admin = False).order_by(User.bad_record.desc()).limit(num+10)
    data = []
    for i in users[num:num+10]:
        tmp = {}
        tmp['name']  = i.name
        tmp['account'] = i.account
        tmp['status'] = True if r.get(i.account) else False # 表示司机是否司机在开车
        tmp['bad_record'] = i.bad_record
        tmp['age'] = i.get_age()
        tmp['work_day'] = i.get_work_day()
        latest_act = i.drive_record
        act = i.drivers_act.filter_by(user_drive_record = latest_act).order_by(Drivers_act.end_time.desc())[0]
        tmp['drive'] = {
            'time':act.end_time if act else 0,
            'type':act.desc if act else 'None'
        }
        data.append(tmp)
    if not data:
        return error('没有数据！')
    return succeed(data)


@adminapi.route('/get_workers_act',methods = ['post'])
@admin_required
@login_required
def get_workers_act():
    account = request.get_json(force=True).get('account')
    num = int(request.get_json(force=True).get('num',0))
    if not account:
        return error('没有数据')
    user = User.query.filter_by(account = int(account)).first()
    type = user.drivers_act.group_by('desc').all()
    print(user.drivers_act.all())
    nums = []
    for x in type:
        tm = {
            x.desc:user.drivers_act.filter_by(desc = x.desc).count(),
            'pic':[i.pic for i in user.drivers_act.filter_by(desc = x.desc).order_by(Drivers_act.end_time.desc()).limit(4)]
        }
        nums.append(tm)
    # print(func.count(user.drivers_act.group_by('desc')))
    # print(user.drivers_act.group_by(Drivers_act.desc).limit(num+10).all())

    # acts = user.drivers_act.order_by(Drivers_act.end_time.desc()).limit(num+10)
    data = {}
    # for i in acts[num:num+10]:
    #     tmp = {}
    #     tmp['time'] = i.end_time
    #     tmp['desc'] = i.desc
    #     tmp['place'] = i.place
    #     tmp['act_id'] = i.act_id
    #     data.append(tmp)
    data['count'] = nums

    if not data:
        return error('没有数据')
    return succeed(data)