#!/usr/bin/env python
# coding=utf-8
# encoding: utf-8
from flask import Blueprint, current_app, request, session, redirect,render_template
from sqlalchemy.exc import IntegrityError
from website.models import User
from flask_login import login_user,login_required,logout_user
from website.helpers.tools import error,succeed
import datetime

oauth = Blueprint('oauth', __name__)

@oauth.route('/regester',methods = ['post'])
def regesters():
    (account,password) = (request.get_json(force=True).get('account'),request.get_json(force=True).get('password'))
    (name,birth,work_start_time) = (request.get_json(force=True).get('name'),request.get_json(force=True).get('birth'),request.get_json(force=True).get('work_start_time'))
    if not ( account and password and name and birth and work_start_time ):
        return error("缺少参数！")
    try:
        birth = datetime.date.fromtimestamp(int(birth)) #10位unix时间戳
        work_start_time = datetime.date.fromtimestamp(int(work_start_time))
    except:
        return error('参数错误！')
    try:
        user = User(account,password)
        user.work_start_time = work_start_time
        user.name = name
        user.birth = birth
        user.save()
    except IntegrityError:
        return error('用户已经存在！')
    return succeed('创建成功！')

@oauth.route('/create_superadmin',methods = ['post'])
def regester():
    (account,password) = (request.get_json(force=True).get('account'),request.get_json(force=True).get('password'))

    (name, birth, work_start_time) = (request.get_json(force=True).get('name'), request.get_json(force=True).get('birth'), request.get_json(force=True).get('work_start_time'))
    if not (account and password and name and birth and work_start_time):
        return error("缺少参数！")
    try:
        birth = datetime.date.fromtimestamp(int(birth))  # 10位unix时间戳
        work_start_time = datetime.date.fromtimestamp(int(work_start_time))
    except:
        return error('参数错误！')

    try:
        user = User(account,password)
        user.work_start_time = work_start_time
        user.name = name
        user.birth = birth
        user.is_admin = True
        user.save()
    except IntegrityError:
        return error('用户已经存在！')

    return succeed('创建成功！')

@oauth.route('/login',methods = ['post'])
def login():
    print(request.get_json(force=True).get('account'))
    (account,password) = (request.get_json(force=True).get('account'),request.get_json(force=True).get('password'))
    if not account or not password:
        return error("no password or account!")
    user = User.query.filter_by(account=account).first()
    if not user:
        return error("没有这个用户！")
    if user.password == password:
        try:
            login_user(user)
            return succeed({
                'name':user.name,
                'age':user.get_age(),
                'work_age':user.get_work_day(),
                'account':user.account,
                'bad_record':user.bad_record
            })
        except Exception as e:
            return error('登录失败！{}'.format(e))
    else:
        return error("登录失败！",code='001')


@oauth.route("/logout",methods = ['post'])
@login_required
def logout():
    logout_user()
    return succeed('登出成功！')