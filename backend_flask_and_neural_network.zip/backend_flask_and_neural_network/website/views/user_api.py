#!/usr/bin/env python
# coding=utf-8
import datetime
from flask import Blueprint,session,request,current_app
from website.models import User,Drivers_act
from website.helpers.tools import succeed, error
from flask_login import login_required,current_user
# from website.PredictModel.model_predict import predict,resultconert
import os,time,random,redis
from PIL import Image
from io import BytesIO
r = redis.Redis(host='localhost', port=6379, decode_responses=True)


userapi = Blueprint('user_api', __name__)

@userapi.route('/get_useract',methods = ['post'])
@login_required
def user_info():
    try:
        num = int(request.get_json(force=True).get('num',0))
    except TypeError:
        return error('参数错误')
    user = current_user
    act = user.drivers_act
    data = []
    for i in act[num:num+10]:
        tmp = {}
        tmp['time'] = i.start_time
        tmp['desc'] = i.desc
        tmp['place'] = i.place
        tmp['actid'] = i.act_id
        data.append(tmp)
    if not data:
        return error('没有数据！')
    return succeed(data)

# @userapi.route('/create_act',methods = ['post'])
# @login_required
# def createact():
#     (time,desc,place,actid) = (request.get_json(force=True).get('time'),request.get_json(force=True).get('desc'),request.get_json(force=True).get('place'),
#                                request.get_json(force=True).get('actid'))
#     if not (time and desc and place and actid):
#         return error('缺少参数!',code='003')
#     time = datetime.fromtimestamp(int(time)) #time 10位unix时间戳
#
#     act = Drivers_act(time=time,desc=desc,place=place,act_id=int(actid))
#     act.save()
#     user = current_user
#     user.drivers_act.append(act)
#     user.save()
#     return succeed("添加成功！")
ALLOWED_EXTENSIONS = set([ 'png', 'jpg', 'jpeg'])
def allowed_file(filename):
    # return '.' in filename and \
    #        filename.rsplit('.', 1)[1] in ALLOWED_EXTENSIONS
    return filename in ALLOWED_EXTENSIONS
def secure_filename(s):
    return s.replace("\\",'')

@userapi.route('/start_drive',methods = ['post'])
@login_required
def startdrive():
    status = session.get('start', 2)
    if status == 1:
        return error('已经开始行车了')

    r.setex('{}'.format(current_user.account),1,4*3600) #用户在线时长，设置为每次最多开车4个小时
    session['start'] = 1
    session['start_time'] = int(time.mktime(datetime.datetime.now().timetuple()))
    user = current_user
    record = user.drive_record #用户行车记录加一
    record = record + 1
    user.drive_record = record
    session['record'] = record
    user.save()
    return succeed("开始行车")

@userapi.route('/end_drive',methods = ['post'])
@login_required
def enddrive():
    status = session.get('start',2)
    if status == 1:
        session['start'] = 0
        # session['end_time'] = int(time.mktime(datetime.datetime.now().timetuple()))
        r.set('{}'.format(current_user.account),0) #redis 储存司机开车状态
        return succeed('结束行车')
    elif status == 0:
        return error("已经结束",code='008')
    else:
        return error("没有开始",code='009')


@userapi.route('/analyze',methods = ['post'])
@login_required
def ana():
    if not session.get('start') == 1:
        return error('您还没有开始行车！')
    elif session.get('start') == 0:
        return error('您已经结束行车！')
    # print('data:',request.get_data())

    # print(type(request.stream.read()))
    file = request.get_data()
    # print('file:',file)
    # import pickle, json

    image = Image.open(BytesIO(file))
    file = image

    # print(json.loads(file))
    # print(pickle.loads(file))

    #test

    #end
    if file and allowed_file(file.format.lower()):
        end_time = datetime.datetime.now()  # 当前时间
        base_path = os.path.abspath(os.path.dirname(os.path.dirname(__file__)))
        pic_name = current_user.account + end_time.strftime('%Y%m%d%H%M%S')
        upload_path = os.path.join(base_path, 'static', secure_filename("{0}.{1}".format(pic_name,'png')))
        file.save(upload_path)
        #在这里调用分析函数
        # res = resultconert(predict(upload_path))
        # if() 成功则创建数据库记录否则用redis 缓存中途记录

        #test 随机返回
        res = ['c1','c2','c3','c4'][random.randint(0,3)]

        #end test

        if not res == 'None':
            act = Drivers_act(desc=res,record=session['record'],start=datetime.datetime.fromtimestamp(session['start_time']),
                              end= end_time )
            act.pic = pic_name
            act.save()
            user = current_user
            user.bad_record = user.bad_record + 1
            user.drivers_act.append(act)
            user.save()

            data = {
                'time':int(time.mktime(end_time.timetuple())) ,#10位时间戳
                'type':res  #识别出的错误类型
            }
            return succeed(data)
        else:
            # r.lpush('{}'.format(current_user.account),'{}'.format(res+end_time.strftime('%Y%m%d%H%M%S')))
            return succeed({
                'time':int(time.mktime(end_time.timetuple())) ,#10位时间戳
                'type':res  #识别出的错误类型
            })
    else:
        return error("没有文件")

@userapi.route('/history',methods = ['post'])
@login_required
def historyr():
    user = current_user
    type = user.drivers_act.group_by('desc').all()
    # print(user.drivers_act.all())
    nums = []
    for x in type:
        tm = {
            x.desc:user.drivers_act.filter_by(desc = x.desc).count(),
            'pic':[i.pic for i in user.drivers_act.filter_by(desc = x.desc).order_by(Drivers_act.end_time.desc()).limit(4) if i.pic]
        }
        nums.append(tm)
    if not nums:
        return error('没有数据')
    return succeed(nums)

@userapi.route('/score',methods = ['post'])
@login_required
def describes():
    user = current_user
    record = user.drive_record
    act = user.drivers_act.filter_by(user_drive_record = record).count()
    if not act:
        return error("没有记录")
    return succeed('{}'.format(100-3*act))



if '__name__' == '__main__':
    print(os.path.abspath(os.path.dirname(__file__)))