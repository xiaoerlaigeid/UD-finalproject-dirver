#!/usr/bin/env python
# coding=utf-8

from website.views.oauth import oauth
from website.views.admin_api import adminapi
from website.views.user_api import userapi
__all__ = ['oauth','adminapi','userapi']
