#!/usr/bin/env python
# coding=utf-8
from extensions import db
from website.models import Tag

subject = ["高数","英语","大物"]
for i in subject:
    tag = Tag(i)
    tag.save()