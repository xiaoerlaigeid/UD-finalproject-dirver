#!/usr/bin/env python
# coding=utf-8

from flask import jsonify
import datetime

def succeed(data=''):
    return jsonify({'data': data, 'status': True})


def error(msg='', code=0, data=None):
    if data:
        return jsonify({'status': False, 'msg': msg, 'code': code, 'data': data})
    return jsonify({'status': False, 'msg': msg, 'code': code})
