#!/usr/bin/env python
# coding=utf-8
from flask_login import current_user
from website.helpers.tools import error
from functools import wraps

def admin_required(func):
    @wraps(func)
    def inner(*args,**kwargs):
        user = current_user
        if not user:
            return error('管理员您未登录')
        if user.is_admin:
            return func()
        else:
            return error('不是管理员！',code='005')
    return inner
