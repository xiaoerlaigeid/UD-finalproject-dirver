#!/usr/bin/env python
# coding=utf-8

import logging
import os
from logging.handlers import SMTPHandler, RotatingFileHandler
from website.helpers.error_handlers import CustomFlaskErr

from flask import Flask,session
from flask_login import LoginManager
from website.helpers.tools import error
import website.views,json
from website.extensions import db
from website.models import User
from website.views import *
from flask_cors import CORS
from flask_session import Session

BLUEPRINTS = (
    (oauth, '/api/account'),
    (userapi,'/api/user'),
    (adminapi,'/api/admin')
)

login_manager = LoginManager()
@login_manager.user_loader
def load_user(user_id):
    return User.query.filter_by(id=user_id).first()

@login_manager.unauthorized_handler
def unauthorized():
    # do stuff
    return error('未登录!', code='002')

def create_app(config=None):
    # instance_path = os.path.abspath(os.path.dirname(__file__))
    # app = Flask(__name__, instance_path=instance_path, instance_relative_config=True)
    app = Flask(__name__)

    # config
    app.config.from_pyfile(config)
    configure_extensions(app)
    configure_errorhandlers(app)
    configure_logging(app)

    # 配置跨域
    CORS(app)

    login_manager.init_app(app)
    # 配置后台session
    # sess = Session()
    # sess.init_app(app)
    Session(app)

    # register blueprint
    configure_blueprint(app, BLUEPRINTS)
    return app


def configure_extensions(app):
    db.init_app(app)


def configure_blueprint(app, modules):

    for profile, url_prefix in modules:
        app.register_blueprint(profile, url_prefix=url_prefix)


def configure_errorhandlers(app):
    #自定义错误处理程序
    @app.errorhandler(CustomFlaskErr)
    def handle_flask_error(error):
        # response 的 json 内容为自定义错误代码和错误信息
        response = json.dumps(error.to_dict())
        return response
    @app.errorhandler(401)
    def unauthorized(e):
        # if request.is_xhr:
        return 'Login required'

    @app.errorhandler(403)
    def forbidden(e):
        return 'Sorry, page not allowed'

    @app.errorhandler(404)
    def page_not_found(e):
        return 'Sorry, page not found'

    @app.errorhandler(500)
    def server_error(e):
        return 'Sorry, an error has occurred'


def configure_logging(app):
    mail_handler = \
        SMTPHandler(app.config['MAIL_SERVER'],
                    app.config['DEFAULT_MAIL_SENDER'],
                    app.config['ADMINS'],
                    'application error',
                    (
                        app.config['MAIL_USERNAME'],
                        app.config['MAIL_PASSWORD'],
                    ))

    mail_handler.setLevel(logging.ERROR)
    app.logger.addHandler(mail_handler)

    formatter = logging.Formatter(
        '%(asctime)s %(levelname)s: %(message)s '
        '[in %(pathname)s:%(lineno)d]')

    debug_log = os.path.join(app.root_path,
                             app.config['DEBUG_LOG'])

    debug_file_handler = \
        RotatingFileHandler(debug_log,
                            maxBytes=100000,
                            backupCount=10)

    debug_file_handler.setLevel(logging.DEBUG)
    debug_file_handler.setFormatter(formatter)
    app.logger.addHandler(debug_file_handler)

    error_log = os.path.join(app.root_path,
                             app.config['ERROR_LOG'])

    error_file_handler = \
        RotatingFileHandler(error_log,
                            maxBytes=100000,
                            backupCount=10)

    error_file_handler.setLevel(logging.ERROR)
    error_file_handler.setFormatter(formatter)
    app.logger.addHandler(error_file_handler)
