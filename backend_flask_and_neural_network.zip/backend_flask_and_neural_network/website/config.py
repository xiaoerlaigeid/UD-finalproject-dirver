#coding:utf-8

DEBUG = True
SECRET_KEY = '3c8bbbdd9bf770459e7f32b490eccc9b'

import os
basedir = os.path.abspath(os.path.dirname(__file__))
SQLALCHEMY_DATABASE_URI ='sqlite:///' + os.path.join(basedir, 'data.sqlite')
SQLALCHEMY_ECHO = False
SQLALCHEMY_TRACK_MODIFICATIONS = False

# UPLOADS_DEFAULT_DEST = '/path/to/app/static/'
# UPLOADS_DEFAULT_URL = '/static'
UPLOAD_FOLDER = '/static'

DEBUG_LOG = 'logs/debug.log'
ERROR_LOG = 'logs/error.log'

ADMINS = ('yourname@domain.com',)

MAIL_SERVER = 'smtp.gmail.com'
MAIL_PORT = 465
MAIL_USE_TLS = False
MAIL_USE_SSL = True
MAIL_DEBUG = DEBUG
MAIL_USERNAME = 'username'
MAIL_PASSWORD = 'password'
DEFAULT_MAIL_SENDER = 'yourname@domain.com'

#session
SESSION_TYPE = 'redis'
SESSION_USE_SIGNER = True

#redis
REDIS_HOST = "127.0.0.1"
REDIS_PORT = 6379