import requests


url = 'http://127.0.0.1:5000/api/user/start_drive'
files = {'file': open("E:\\javascript\\Pictures\\test.jpg", 'rb')}
print(requests.post(url,files=files).text)