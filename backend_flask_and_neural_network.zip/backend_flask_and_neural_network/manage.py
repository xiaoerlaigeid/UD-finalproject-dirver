#!/usr/bin/env python
# coding=utf-8

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from flask_script import Manager, prompt_bool
from website import create_app
from website.extensions import db
from website.models import User
from flask_migrate import Migrate,MigrateCommand
from flask_session import Session

app = create_app('config.py')
app.config['secret_key'] = '3c8bbbdd9bf770459e7f32b490eccc9b'
SESSION_TYPE = 'redis'
SESSION_USE_SIGNER = True
Session(app)

migrate = Migrate(app, db)

manager = Manager(app, with_default_commands=False)
manager.add_command('db', MigrateCommand)




@manager.shell
def make_context():
    return dict(app=app, db=db)


@manager.option('-c', '--config', dest='config', help='Configuration file name', default='config.py')
@manager.option('-H', '--host', dest='host', help='Host address', default='0.0.0.0')
@manager.option('-p', '--port', dest='port', help='Application port', default=63341,type=int)
def runserver(config, host, port):
    app = create_app(config)
    app.run(host=host, port=port, threaded=True)


@manager.command
def createall():
    "Creates database tables"
    print('Need dropall database before createall')
    dropall()
    db.create_all()
    print('createall ok')


@manager.command
def dropall():
    "Drops all database tables"
    if prompt_bool("Are you sure ? You will lose all your data !"):
        db.drop_all()
        print('dropall ok')


if __name__ == '__main__':
    manager.run()
