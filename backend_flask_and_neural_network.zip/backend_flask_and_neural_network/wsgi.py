#!/usr/bin/env python

from website import create_app

app = create_app('config.py')

